// 记忆卡片生成器 · L4 互动演示
// 数据流：textarea → JSON.parse → 渲染卡片网格 → 状态标记 + 持久化

(function () {
  const STORAGE_KEY = 'memory-cards-state-v1';

  // ============ 数据 ============
  let cards = [];
  let states = {}; // {cardIndex: 'done' | 'half' | 'bad'}

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) states = JSON.parse(raw) || {};
    } catch (e) {
      states = {};
    }
  }
  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(states));
    } catch (e) {}
  }

  // ============ DOM ============
  const $input = document.getElementById('json-input');
  const $gen = document.getElementById('gen-btn');
  const $demo = document.getElementById('demo-btn');
  const $download = document.getElementById('download-btn');
  const $clear = document.getElementById('clear-btn');
  const $grid = document.getElementById('card-grid');
  const $error = document.getElementById('error-msg');
  const $stats = document.getElementById('stats');
  const $statTotal = document.getElementById('stat-total');
  const $statDone = document.getElementById('stat-done');
  const $statHalf = document.getElementById('stat-half');
  const $statBad = document.getElementById('stat-bad');

  // ============ 示例数据 ============
  const DEMO_JSON = [
    { front: "判别式 Δ>0 的几何意义", back: "抛物线和 x 轴相交两点，有两个不同实根", topic: "一元二次方程" },
    { front: "判别式 Δ=0 的根", back: "只有一个重根，抛物线刚好擦过 x 轴", topic: "一元二次方程" },
    { front: "判别式 Δ<0 的情况", back: "无实根（实数范围内），抛物线整个在 x 轴上方或下方", topic: "一元二次方程" },
    { front: "配方法的四步顺序", back: "移项 → 系数归 1 → 配完全平方 → 开方（带 ± 号）", topic: "一元二次方程" },
    { front: "「无实数根」和「无解」的区别", back: "实数范围内「无实数根」= 这道题在初中无解；复数范围内所有方程都有解", topic: "一元二次方程" }
  ];

  // ============ 渲染 ============
  function renderStats() {
    if (!cards.length) {
      $stats.hidden = true;
      return;
    }
    $stats.hidden = false;
    $statTotal.textContent = cards.length;
    let done = 0, half = 0, bad = 0;
    cards.forEach((_, i) => {
      const s = states[i];
      if (s === 'done') done++;
      else if (s === 'half') half++;
      else if (s === 'bad') bad++;
    });
    $statDone.textContent = done;
    $statHalf.textContent = half;
    $statBad.textContent = bad;
  }

  function renderCards() {
    $grid.innerHTML = '';
    if (!cards.length) {
      $grid.innerHTML = '<div class="empty-hint">还没有卡片。粘贴 JSON 后点「生成卡片」试试。</div>';
      return;
    }
    cards.forEach((c, i) => {
      const card = document.createElement('div');
      card.className = 'memory-card';
      card.dataset.idx = i;

      const state = states[i];
      if (state === 'done') card.classList.add('is-done');
      else if (state === 'half') card.classList.add('is-half');
      else if (state === 'bad') card.classList.add('is-bad');

      card.innerHTML = `
        <div class="card-face card-front">
          <div class="card-topic">${escapeHtml(c.topic || '')}</div>
          <div class="card-content">${escapeHtml(c.front)}</div>
          <div class="card-hint">点击翻面</div>
        </div>
        <div class="card-face card-back">
          <div class="card-content">${escapeHtml(c.back)}</div>
          <div class="card-actions">
            <button class="mark-btn mark-done" data-state="done" title="已掌握">✓</button>
            <button class="mark-btn mark-half" data-state="half" title="半掌握">△</button>
            <button class="mark-btn mark-bad" data-state="bad" title="未掌握">✗</button>
          </div>
        </div>
      `;

      // 翻面
      card.addEventListener('click', function (e) {
        if (e.target.closest('.mark-btn')) return;
        card.classList.toggle('flipped');
      });

      // 标记状态
      card.querySelectorAll('.mark-btn').forEach(btn => {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          const newState = btn.dataset.state;
          const oldState = states[i];
          if (oldState === newState) {
            delete states[i];
            card.classList.remove('is-done', 'is-half', 'is-bad');
          } else {
            states[i] = newState;
            card.classList.remove('is-done', 'is-half', 'is-bad');
            card.classList.add('is-' + newState);
          }
          saveState();
          renderStats();
        });
      });

      $grid.appendChild(card);
    });
    renderStats();
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, ch => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[ch]));
  }

  function showError(msg) {
    $error.textContent = msg;
    $error.hidden = false;
  }
  function clearError() {
    $error.hidden = true;
  }

  // ============ 事件 ============
  $gen.addEventListener('click', function () {
    clearError();
    const raw = $input.value.trim();
    if (!raw) {
      showError('输入框是空的。先把 AI 输出的 JSON 粘贴进来，或者点「填入示例」试试。');
      return;
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      showError('JSON 格式不对：' + e.message + '。请检查是不是少了 [ 或 ]，或者多了 AI 的解释文字。');
      return;
    }
    if (!Array.isArray(parsed)) {
      showError('JSON 必须是一个数组（用 [ ] 包的），不是单个对象。');
      return;
    }
    const cleaned = parsed.map(c => ({
      front: c.front || c.q || c.question || '',
      back: c.back || c.a || c.answer || '',
      topic: c.topic || ''
    })).filter(c => c.front && c.back);
    if (!cleaned.length) {
      showError('没找到有效的卡片。请检查每张卡片是否包含 front 和 back 字段。');
      return;
    }
    cards = cleaned;
    states = {};
    saveState();
    renderCards();
  });

  $demo.addEventListener('click', function () {
    clearError();
    $input.value = JSON.stringify(DEMO_JSON, null, 2);
  });

  $download.addEventListener('click', function () {
    if (!cards.length) {
      showError('还没有卡片可以下载。先点「生成卡片」再下载。');
      return;
    }
    const payload = {
      generated_at: new Date().toISOString(),
      states: states,
      cards: cards
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `memory-cards-${date}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  $clear.addEventListener('click', function () {
    clearError();
    cards = [];
    states = {};
    $input.value = '';
    localStorage.removeItem(STORAGE_KEY);
    renderCards();
  });

  // ============ 初始化 ============
  loadState();
  renderCards();
})();